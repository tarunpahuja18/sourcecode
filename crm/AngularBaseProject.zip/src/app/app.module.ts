import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AuthenticationService } from './common/index';
import { BrowserXhr, HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule, Router, ActivatedRoute} from "@angular/router";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgProgressModule, NgProgressInterceptor, NgProgressBrowserXhr } from 'ngx-progressbar';
import { AuthGuard } from './shared/index';
import { AppRoutingModule } from './app-routing.module';
import { SlimScrollModule } from 'ng2-slimscroll';
import { DynamicComponentService } from './common/services/dynamiccomponent.service';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    BrowserAnimationsModule,
    FormsModule,
    AppRoutingModule,
    //Ng2BootstrapModule,
    NgProgressModule,
    SlimScrollModule
  ],
  providers: [AuthGuard, AuthenticationService, DynamicComponentService,
    { provide: BrowserXhr, useClass: NgProgressBrowserXhr },],
  bootstrap: [AppComponent]
})
export class AppModule { }
