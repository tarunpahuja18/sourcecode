import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignleads',
  templateUrl: './assignleads.component.html',
  styleUrls: ['./assignleads.component.css']
})
export class AssignleadsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
