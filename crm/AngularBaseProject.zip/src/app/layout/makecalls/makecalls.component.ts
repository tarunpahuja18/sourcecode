import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-makecalls',
  templateUrl: './makecalls.component.html',
  styleUrls: ['./makecalls.component.css']
})
export class MakecallsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
