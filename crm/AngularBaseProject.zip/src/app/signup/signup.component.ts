﻿import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class signupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
