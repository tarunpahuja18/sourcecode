export const environment = {
  production: true,
  apiUrl: 'https://abc.com.net/api/',
};
