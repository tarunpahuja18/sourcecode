﻿
Partial Class src_styles_app
    Inherits System.Web.UI.Page

End Class
